<?php
/*
Plugin Name: OWS Share Button
Plugin URI: https://ows.codes/
Description: A lightweight and straightforward social share button built by OWS Codes providing a better user experience and web share API.
Version: 1.1
Author: OWS.Codes
Author URI: https://ows.codes/
*/
function ows_scripts() {
    wp_enqueue_style('ows-style', plugin_dir_url( __FILE__  ). 'style.css');
    wp_enqueue_script('ows-js', plugin_dir_url( __FILE__  ) . 'script.js', array(), '1.0.0', 'true' );
    /*
    Remove this line if you have issue with your previous font awesome, or contact ows.codes for help
    wp_enqueue_style('ows-icon', plugin_dir_url( __FILE__  ). 'font-awesome-4.7.0/css/font-awesome.min.css');
    */
}
add_action('wp_enqueue_scripts', 'ows_scripts');

add_action('wp_enqueue_scripts', 'ows_fonts', 99999);

function ows_fonts() {
  global $wp_styles;
  $srcs = array_map('basename', (array) wp_list_pluck($wp_styles->registered, 'src') );
  if ( in_array('font-awesome.css', $srcs) || in_array('font-awesome.min.css', $srcs)  ) {
  } else {
    wp_enqueue_style('ows-icon', plugin_dir_url( __FILE__  ). 'font-awesome-4.7.0/css/font-awesome.min.css');
  }
}

function ows_load_jquery() {
    if ( ! wp_script_is('jquery', 'enqueued')) {
        wp_enqueue_script('jquery');
    }
}
add_action('wp_enqueue_scripts', 'ows_load_jquery');

function ows_add_share() {    
        $ows_share_float = '<div class="ows-left ows-icon-bar" id="ows-desktop">
        <span class="ows-facebook" data-ows-share="facebook" title="Share on Facebook."><i class="fa fa-facebook"></i></span> 
        <span class="ows-twitter" data-ows-share="twitter" title="Tweet this Article"><i class="fa fa-twitter"></i></span> 
        <span class="ows-whatsapp" data-ows-share="whatsapp"><i class="fa fa-whatsapp"></i></span>
        <span class="ows-email" data-ows-share="mail"><i class="fa fa-envelope"></i></span>
        <span class="ows-share" data-share-api="open"><i class="fa fa-share"></i></span>
        </div>';
    echo $ows_share_float;
    
$ows_open = '<div class="ows-share-dialog">
<div class="ows-share-header">
<p class="ows-dialog-title">Share</p>
<span class="ows-close-button" id="ows-close-button"><i class="fa fa-close"></i></span>
</div>
<div class="ows-targets">
<span class="ows-button" data-ows-share="facebook"><i class="fa fa-facebook"></i> Facebook</span>
<span class="ows-button" data-ows-share="twitter"><i class="fa fa-twitter"></i> Twitter</span>
<span class="ows-button" data-ows-share="whatsapp"><i class="fa fa-whatsapp"></i> WhatsApp</span>
<span class="ows-button" data-ows-share="telegram"><i class="fa fa-telegram"></i> Telegram</span>
</div>
<div class="ows-link">
<div class="ows-url">'.get_the_permalink().'</div>
<button class="ows-button ows-copy-link" id="ows-copy-link"> Copy</button>
<div id="snackbar">Link copied to clipboard</div>
</div>
</div>';
	echo $ows_open;
    
    $ows_share_sticky = '<div class="ows-left ows-share-bar" id="ows-mobile">
    <ul class="ows-share-bar--list">
	    <li class="facebook ows-share-bar--item">
	      <span class="ows-share-bar--item-link" data-ows-share="facebook" title="Share on Facebook.">
	      </span>
	    </li>
	    <li class="twitter ows-share-bar--item">
	      <span class="ows-share-bar--item-link" data-ows-share="twitter" title="Tweet this Article">
	      </span>
	    </li>
	    <li class="whatsapp ows-share-bar--item">
	      <span class="ows-share-bar--item-link" data-ows-share="whatsapp">
	      </span>
	    </li>
	    <li class="reddit ows-share-bar--item">
	      <span class="ows-share-bar--item-link" data-ows-share="reddit" title="Share on Reddit">
	      </span>
	    </li>
	    <li class="share-ows ows-share-bar--item">
	      <span class="ows-share-bar--item-link" data-share-api="open">
	      </span>
	    </li>
	  </ul>
	</div>';
	echo $ows_share_sticky;
}
add_action('get_footer', 'ows_add_share');