/*! OWS Share v1.0.0  | ows.codes/ */
jQuery(document).ready(function(){jQuery("[data-ows-share]").click(function(){
var ows_share_link =encodeURIComponent(window.location.href), 
ows_share_title =encodeURIComponent(document.title),
ows_title =document.title;
switch(jQuery(this).attr("data-ows-share")){
case"facebook":
ows_share="https://www.facebook.com/sharer.php?u="+ows_share_link+"&quote="+ows_share_title;
break;
case"twitter":
ows_share="https://twitter.com/intent/tweet?url="+ows_share_link+"&text="+ows_share_title;
break;
case"whatsapp":
ows_share="whatsapp://send?text=*"+ows_share_title+"* "+ows_share_link;
break;
case"telegram":
ows_share="https://telegram.me/share/url?text="+ows_share_title+"&url="+ows_share_link;
break;
case"mail":
ows_share="mailto:?subject="+ows_title+"&body="+ows_share_link;
break;
case"reddit":
ows_share="http://reddit.com/submit?url="+ows_share_link+"&title="+ows_title;
break;
default:
ows_share = '#';
}
if(ows_share) {
window.open(ows_share,"_blank");
}
})    
}
);
jQuery(document).ready(function(){
 function ows_convert(text){
 const span = document.createElement('span');
 return text
 .replace(/&[#A-Za-z0-9]+;/gi, (entity,position,text)=> {
 span.innerHTML = entity;
 return span.innerText;
 });
}
const shareButton = document.querySelector('.ows-share-button');
const shareDialog = document.querySelector('.ows-share-dialog');
const closeButton = document.querySelector('.ows-close-button');
jQuery("[data-share-api]").click(function(){
if (navigator.share) {
var ows_link =window.location.href, 
ows_title=ows_convert(document.title);
navigator.share({
title: ows_title,
url: ows_link
}).then(() => {
console.log('Thanks for sharing!');
})
.catch(console.error);
} else {
shareDialog.classList.add('ows-is-open');
}
});
jQuery("#ows-close-button").click(function(){
shareDialog.classList.remove('ows-is-open');
});
jQuery("#ows-copy-link").click(function(){
var e=(t=document.getElementsByClassName("ows-url"))[0].innerHTML;  
const n=document.createElement("textarea");
var t;n.value=e,document.body.appendChild(n),n.select(),document.execCommand("copy"),document.body.removeChild(n),(t=document.getElementById("snackbar")).className="show",setTimeout(function(){t.className=t.className.replace("show","")},3e3)
});
});